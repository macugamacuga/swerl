package com.example.swerl

data class ItemsViewModel(val post:Int,val username:String,val likes:Int,val profile:Int ){

}
